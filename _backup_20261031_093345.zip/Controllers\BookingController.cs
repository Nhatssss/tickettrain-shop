using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TrainTicketWeb.Models;
using TrainTicketWeb.Services;
using TrainTicketWeb.ViewModels;

namespace TrainTicketWeb.Controllers;

[Authorize]
public class BookingController : Controller
{
    private readonly IBookingService _bookings;
    private readonly IScheduleService _schedules;
    private readonly IStationService _stations;
    private readonly ITrainService _trains;
    private readonly IUserService _users;

    public BookingController(IBookingService bookings, IScheduleService schedules,
        IStationService stations, ITrainService trains, IUserService users)
    {
        _bookings = bookings;
        _schedules = schedules;
        _stations = stations;
        _trains = trains;
        _users = users;
    }

    private int CurrentUserId => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));

    // ===== Chọn chỗ =====
    [HttpGet]
    public IActionResult SelectSeats(int tripId, int fromId, int toId, string leg = "outbound", int passengerCount = 1)
    {
        var trip = _schedules.GetTrip(tripId);
        if (trip == null) return RedirectToAction("Index", "Home");

        var vm = new SeatSelectViewModel
        {
            TripId = tripId,
            TrainCode = trip.TrainCode,
            RouteName = trip.RouteName,
            DepartureDate = trip.DepartureDate,
            FromStationId = fromId,
            ToStationId = toId,
            FromStationName = _stations.GetStation(fromId)?.StationName,
            ToStationName = _stations.GetStation(toId)?.StationName,
            Leg = leg,
            PassengerCount = passengerCount,
            Coaches = _bookings.GetSeatMap(tripId, fromId, toId)
        };
        return View(vm);
    }

    // ===== Giữ chỗ (POST) =====
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Hold(int tripId, int fromId, int toId, string leg, int passengerCount, List<int> seatIds)
    {
        if (seatIds == null || seatIds.Count == 0)
        {
            TempData["Error"] = "Vui lòng chọn ít nhất một chỗ.";
            return RedirectToAction("SelectSeats", new { tripId, fromId, toId, leg, passengerCount });
        }
        if (seatIds.Count != passengerCount)
        {
            TempData["Error"] = $"Bạn cần chọn đúng {passengerCount} chỗ (đã chọn {seatIds.Count}).";
            return RedirectToAction("SelectSeats", new { tripId, fromId, toId, leg, passengerCount });
        }

        var user = _users.GetById(CurrentUserId);
        var picks = new List<SeatPick>();
        foreach (var sid in seatIds)
        {
            picks.Add(new SeatPick
            {
                TripId = tripId,
                SeatId = sid,
                FromId = fromId,
                ToId = toId,
                Leg = leg,
                CoachTypeId = _trains.GetCoachTypeOfSeat(sid)
            });
        }

        var (bookingId, error) = _bookings.CreateBooking(CurrentUserId, "one_way",
            user?.Email ?? "", user?.Phone ?? "0000000000", picks);

        if (bookingId == 0)
        {
            TempData["Error"] = error;
            return RedirectToAction("SelectSeats", new { tripId, fromId, toId, leg, passengerCount });
        }
        return RedirectToAction("Passengers", new { bookingId });
    }

    // ===== Nhập thông tin hành khách =====
    [HttpGet]
    public IActionResult Passengers(int bookingId)
    {
        var b = _bookings.GetBooking(bookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");

        var vm = new PassengersViewModel
        {
            BookingId = bookingId,
            BookingCode = b.BookingCode,
            TripType = b.TripType,
            Passengers = _bookings.GetBookingPassengers(bookingId),
            PassengerTypes = _schedules.GetPassengerTypes(activeOnly: true)
        };
        return View(vm);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Passengers(int bookingId, List<int> ticketIds, List<string> names,
        List<string> idNumbers, List<int> passengerTypeIds)
    {
        var b = _bookings.GetBooking(bookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");

        if (ticketIds == null) ticketIds = new List<int>();

        var rows = new List<PassengerRow>();
        for (int i = 0; i < ticketIds.Count; i++)
        {
            string name = (names != null && i < names.Count) ? names[i] : "";
            string idNo = (idNumbers != null && i < idNumbers.Count) ? idNumbers[i] : "";
            int typeId = (passengerTypeIds != null && i < passengerTypeIds.Count) ? passengerTypeIds[i] : 0;

            if (string.IsNullOrWhiteSpace(name))
            {
                TempData["Error"] = "Vui lòng nhập đầy đủ họ tên hành khách.";
                return RedirectToAction("Passengers", new { bookingId });
            }
            var pt = _schedules.GetPassengerType(typeId);
            if (pt != null && !string.IsNullOrEmpty(pt.IdLabel) && string.IsNullOrWhiteSpace(idNo))
            {
                TempData["Error"] = $"Đối tượng '{pt.TypeName}' bắt buộc nhập {pt.IdLabel}.";
                return RedirectToAction("Passengers", new { bookingId });
            }
            rows.Add(new PassengerRow
            {
                TicketId = ticketIds[i],
                PassengerName = name,
                IdNumber = idNo ?? "",
                PassengerTypeId = typeId
            });
        }

        _bookings.UpdatePassengers(bookingId, rows);
        return RedirectToAction("Checkout", new { bookingId });
    }

    // ===== Thanh toán =====
    [HttpGet]
    public IActionResult Checkout(int bookingId)
    {
        var b = _bookings.GetBooking(bookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");
        if (b.Status != "holding") return RedirectToAction("Detail", new { bookingId });
        return View(_bookings.GetBookingDetail(bookingId));
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Pay(int bookingId, string method)
    {
        var b = _bookings.GetBooking(bookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");

        var valid = new[] { "vnpay", "momo", "bank_qr" };
        if (!valid.Contains(method)) method = "bank_qr";

        bool ok = _bookings.Pay(bookingId, method);
        if (!ok)
        {
            TempData["Error"] = "Đơn đã hết hạn giữ chỗ hoặc không ở trạng thái thanh toán.";
            return RedirectToAction("MyBookings");
        }
        return RedirectToAction("Success", new { bookingId });
    }

    public IActionResult Success(int bookingId)
    {
        var vm = _bookings.GetBookingDetail(bookingId);
        if (vm == null || vm.Booking.UserId != CurrentUserId) return RedirectToAction("MyBookings");
        return View(vm);
    }

    // ===== Lịch sử =====
    public IActionResult MyBookings() => View(_bookings.GetMyBookings(CurrentUserId));

    public IActionResult Detail(int bookingId)
    {
        var vm = _bookings.GetBookingDetail(bookingId);
        if (vm == null || vm.Booking.UserId != CurrentUserId) return RedirectToAction("MyBookings");
        return View(vm);
    }

    public IActionResult Ticket(int ticketId)
    {
        var t = _bookings.GetTicketDetail(ticketId);
        if (t == null) return RedirectToAction("MyBookings");
        var b = _bookings.GetBooking(t.Ticket.BookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");
        ViewBag.BookingCode = b.BookingCode;
        return View(t);
    }

    // ===== Hủy vé =====
    [HttpGet]
    public IActionResult Cancel(int ticketId)
    {
        var t = _bookings.GetTicketDetail(ticketId);
        if (t == null) return RedirectToAction("MyBookings");
        var b = _bookings.GetBooking(t.Ticket.BookingId);
        if (b == null || b.UserId != CurrentUserId) return RedirectToAction("MyBookings");

        var depart = _schedules.GetDepartureTime(t.Ticket.TripId, t.Ticket.FromStationId) ?? DateTime.Now.AddHours(1);
        double hours = (depart - DateTime.Now).TotalHours;
        decimal feePct = AppSettings.GetCancelFeePercent(hours);
        decimal fee = Math.Round(t.Ticket.FinalPrice * feePct / 100m, 0);

        ViewBag.Fee = fee;
        ViewBag.Refund = t.Ticket.FinalPrice - fee;
        ViewBag.HoursBefore = hours;
        return View(t);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult CancelConfirmed(int ticketId)
    {
        var (ok, msg, fee, refund) = _bookings.RequestRefund(ticketId, CurrentUserId);
        if (!ok) TempData["Error"] = msg;
        else TempData["Success"] = $"Yêu cầu hủy vé đã được gửi. Phí hủy {fee:N0} VNĐ, số tiền dự kiến hoàn {refund:N0} VNĐ.";
        return RedirectToAction("MyBookings");
    }
}
